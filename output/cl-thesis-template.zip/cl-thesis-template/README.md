# CL Thesis Template @ CIS, LMU Munich

This template provides a complete setup for writing Bachelor's and Master's theses in Computational Linguistics at the Center for Information and Language Processing (CIS), LMU Munich.

## Folder Structure

The template package is organized as follows:
```
thesis-template/
├── thesis.tex
├── BaMaCL.sty
├── thesis.pdf
├── references.bib
├── acl_natbib.bst
├── README.md
└── img/
    ├── lmu_cis_logo.pdf
    └── place_holder.png
```

## Included Files

### Main Files
- `thesis.tex` — Main LaTeX document (edit this file)
- `BaMaCL.sty` — Custom style file for formatting and layout
- `thesis.pdf` — Compiled example output of the template

### Bibliography
- `references.bib` — BibTeX file for managing references (add your cited sources here)
- `acl_natbib.bst` — Bibliography style file used for ACL-style citations

By default, the template includes all entries in `references.bib` using the `\nocite{*}` command in `thesis.tex`. 
If you want to include **only the works you actually cite**, comment out or remove the `\nocite{*}` line in the LaTeX file.

### Images
- `img/lmu_cis_logo.pdf` — LMU & CIS logo for the title page
- `img/place_holder.png` — Placeholder image used in figure examples

### Documentation
- `README.md` — Instructions for setup, usage, and submission

## How to Use

1. Open `thesis.tex` and:
   - Select your degree and language by uncommenting the appropriate `\usepackage[...]{BaMaCL}` line.
   - Fill in the thesis metadata (title, author, supervisor, etc.).
   - Replace all instructional and example content with your own work.

2. Add your references to `references.bib` using standard BibTeX format.

3. Compile `thesis.tex` using pdflatex and bibtex:
   - `pdflatex thesis`
   - `bibtex thesis`
   - `pdflatex thesis` (twice)

## Submission Checklist

- Degree and language selected correctly
- Thesis title filled in
- Author name correct
- Supervisor and examiner names (including academic titles)
- Submission date and working period set
- Abstract written (maximum 250 words)
- All placeholder text and examples removed
- Appendix on "Submitted Software and Data Files" included
- Declaration of authorship included and signed

## Submission Instructions

- Submit two signed print copies to the examination office.
- Email the PDF version and all supplementary material (e.g., code, data) to your supervisor and to the CIS office.
- For official submission information, see: 
  - https://www.cis.lmu.de/bsc/bachelorarbeit/index.html 
  - https://www.cis.lmu.de/master/masterarbeit/index.html

## Printing and Final Submission

- For a print-friendly version, uncomment the line in the PRINT MODE block in `thesis.tex`. This is optional and disables link colors and borders.


## Character Count Requirements

- Bachelor's thesis: approximately 80,000 characters (about 16-17 pages of continuous text)
- Master's thesis: approximately 120,000 characters (about 24-25 pages of continuous text)

These estimates are based on this template and refer to the amount of actual written text (not the full document length). They exclude the title page, figures, tables, bibliography, and any appendix material.